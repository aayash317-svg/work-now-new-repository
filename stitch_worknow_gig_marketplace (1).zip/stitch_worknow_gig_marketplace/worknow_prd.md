# Product Requirements Document: WorkNow

## Project Overview
WorkNow is a real-time on-demand worker booking platform (mobile-first) inspired by the efficiency and real-time nature of ride-sharing apps like Rapido and Uber. It connects customers (those needing short-term jobs done) with nearby workers (students, unemployed individuals, or freelancers looking for gig work).

## Target Audience
1. **Customers:** Individuals or businesses needing quick help with delivery, cleaning, teaching, or general labor.
2. **Workers:** Students and job-seekers looking for immediate, local earning opportunities.

## Visual Identity & Design Principles
- **Style:** Clean, minimal, modern, and friendly.
- **Palette:** Soft blues, greens, and whites to convey trust, growth, and clarity.
- **UI Elements:** Rounded cards, smooth iconography, and a clear visual hierarchy.
- **UX Goal:** Fast interactions, simple navigation (bottom tab bar), and intuitive flows for both posting and accepting jobs.

## Core Features & Screens

### 1. Onboarding & Auth
- **Splash Screen:** Branding and tagline: "Find Work. Find Workers. Instantly."
- **Login/Signup:** Phone-based OTP login.
- **Role Selection:** Clear toggle or selection between "I need a worker" (Customer) and "I want to work" (Worker).

### 2. Customer Experience
- **Home Screen:** High-level search, category grid (Delivery, Cleaning, Helper, Teaching, etc.), "Post a Job" CTA, and a map/list preview of nearby workers.
- **Post Job Flow:** Detailed form (Title, Description, Image Upload, Map Location Picker, Time/Date, and Pricing options).
- **Tracking:** Live map view of the worker's location with status updates ("On the way", "Working", "Completed") and communication tools (Call/Chat).

### 3. Worker Experience
- **Worker Home:** Online/Offline toggle. A feed of nearby job requests with key details (Title, Distance, Pay, Time) and immediate action buttons (Accept/Ignore).
- **Job Details:** Comprehensive view of the job, customer info, and bidding/acceptance tools.
- **Earnings Dashboard:** Daily stats, job history, and wallet management.

### 4. Shared Features
- **Profile:** User verification badges, ratings, and settings.
- **Reviews:** Star rating and text feedback system post-job.
- **Navigation:** Bottom navigation bar for easy access to Home, Jobs/Tasks, Wallet, and Profile.

## Technical Requirements
- Real-time notifications for job alerts.
- Map integration for location-based matching and tracking.
- Secure OTP-based authentication.