# Design System Strategy: The Fluid Professional

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Fluid Professional."** 

In the gig economy, "clean and modern" is the baseline, but to achieve a premium, award-winning feel, we must move beyond the grid-bound "app template." This system is designed to feel authoritative yet effortless. We achieve this through **Editorial Asymmetry**: using dramatic scale shifts in typography and generous, intentional white space that allows the interface to breathe like a high-end magazine. We are not just building a job board; we are building a curated marketplace of opportunity.

By prioritizing tonal depth and glassmorphism over rigid outlines, we create a UI that feels like a series of physical, high-quality layers. This approach builds "Trust" (Primary Blue) through sophisticated execution and "Growth" (Secondary Green) through vibrant, kinetic interaction points.

---

### 2. Colors: Tonal Architecture
We move away from flat, "web-safe" aesthetics by using a sophisticated spectrum of blues and greens, layered through Material-inspired surface tiers.

#### The Palette
*   **Primary (#005da6):** The anchor. Used for high-trust moments and primary navigation.
*   **Secondary (#006d3d):** The "Action" signal. Reserved for "Book Now," "Start Shift," or growth-oriented success states.
*   **Tertiary (#8b4c00):** An earthy warm tone for urgent but non-error alerts (e.g., "Shift starting soon").
*   **Neutrals:** A range of soft, cool grays (`surface-container-low` to `highest`) that create the canvas.

#### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders to define sections or cards. 
Boundaries must be created through background shifts. A card (`surface-container-lowest`) should sit on a page (`surface-container-low`) to define its footprint. If you feel the need for a line, increase the spacing or shift the background tone instead.

#### The "Glass & Gradient" Rule
To add "soul" to the UI:
*   **Signature Gradients:** For primary CTAs, use a subtle linear gradient from `primary` to `primary-container`. This prevents the "flat-button" look and adds tactile depth.
*   **Glassmorphism:** Floating elements (like a bottom-anchored "Apply" bar on mobile) must use a `surface` color at 80% opacity with a `20px` backdrop blur. This ensures the gig listings scroll "behind" the UI, creating a sense of infinite depth.

---

### 3. Typography: Editorial Hierarchy
We use **Inter** as our core typeface. The distinction between "Display" and "Body" is the key to our premium feel.

*   **Display (lg/md/sm):** Used for marketing headers and "Big Numbers" (e.g., your earnings). Tracking should be set to `-0.02em` to feel tight and custom.
*   **Headline & Title:** Use `SemiBold` (600) for job titles. This creates an immediate "Authority" anchor on every card.
*   **Body (lg/md/sm):** Set in `Regular` (400) with a generous `1.5` line height. Content density is the enemy of the gig worker on the move; give the text room to breathe.
*   **Label:** Always `Medium` (500) and often `Uppercase` with `0.05em` letter spacing for a "utility-chic" look.

---

### 4. Elevation & Depth: The Layering Principle
Forget "drop shadows" that look like 2010. We use **Tonal Layering**.

*   **The Layering Principle:** 
    *   **Level 0 (Base):** `surface` (#f8f9ff)
    *   **Level 1 (Sectioning):** `surface-container-low` (#f1f3fb)
    *   **Level 2 (Interactive Cards):** `surface-container-lowest` (#ffffff)
*   **Ambient Shadows:** For elements that *must* float (Modals, FABs), use a shadow with a blur radius of `32px`, an offset of `Y: 8px`, and a color derived from `on-surface` at `6%` opacity. It should feel like a soft glow, not a dark stain.
*   **The "Ghost Border":** For input fields, use `outline-variant` at `20%` opacity. It provides just enough affordance for accessibility without cluttering the visual field.

---

### 5. Components

#### Buttons
*   **Primary:** Large (`56px` height for mobile), `xl` (24px) rounded corners. Gradient fill. Label in `title-sm`.
*   **Secondary:** `surface-container-highest` background with `on-surface` text. No border.
*   **Tertiary:** Transparent background, `primary` text, `SemiBold`.

#### Job Listing Cards
*   **Structure:** No dividers. Use `md` (12px) vertical padding between the Title and the Salary label. 
*   **Status Chips:** Use `secondary-fixed` for "Open" jobs and `tertiary-fixed` for "Urgent." Chips should have `full` (pill) roundedness.
*   **Interaction:** On hover/tap, the card should transition from `surface-container-lowest` to a slightly brighter `surface-bright` rather than growing in size.

#### Mobile Inputs
*   **Fields:** Background `surface-container-low`, no border. On focus, transition to `surface-container-lowest` with a `2px` `primary` "Ghost Border."
*   **Labeling:** Use "Floating Labels" that shrink into the top-left of the field to maximize vertical space for job details.

#### Interactive Lists
*   **No-Divider Rule:** Separate list items with `8px` of vertical margin and a subtle tonal shift between the "Active" item and the "Background."

---

### 6. Do’s and Don’ts

#### Do
*   **DO** use asymmetry in your layouts. Align a headline to the left but place a CTA in a floating container on the right to create visual interest.
*   **DO** use the `secondary-green` sparingly. It is a "reward" color; if everything is green, nothing is important.
*   **DO** use the `xl` (24px) corner radius for high-level containers (cards, modals) and `md` (12px) for nested elements (buttons, inputs).

#### Don’t
*   **DON'T** use black (#000000). Use `on-surface` (#181c21) for all "black" text to maintain the soft, premium feel.
*   **DON'T** use 1px dividers. They create "visual noise" that makes an app feel like a legacy spreadsheet. Use white space.
*   **DON'T** use standard system icons. Use thin-line (1.5pt stroke) custom icons with slightly rounded terminals to match our `roundedness` scale.